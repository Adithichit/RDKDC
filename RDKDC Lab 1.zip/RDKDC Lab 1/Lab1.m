addpath('/home/vboxuser/Desktop/RDKDC Lab 1/UR5ROS2code/UR5ROScode/')
ur5_interface()
ur5e.move_joints(theta,time_intervall)

addpath('/home/vboxuser/Desktop/RDKDC Lab 1/Matlabcodes_Lab1/Matlabcodes_Lab1/')
x_pi2 = ROTX(pi/2)
p_pi2 = [0; 1; 0]
rotatedPoint_pi2 = x_pi2 * p_pi2;

x_pi4 = ROTX(pi/4)
p_pi4 = [0; 1; 0]
rotatedPoint_pi4 = x_pi4 * p_pi4;

figure();
subplot(3,1,1);
plotr(x_pi2)
hold on;
plotr(x_pi4)

subplot(3,1,2)
plotp3(rotatedPoint_pi2)
hold on;
plotp3(rotatedPoint_pi4)

subplot(3,1,3);
plotv3(p_pi2,rotatedPoint_pi2)
hold on;
plotv3(p_pi4, rotatedPoint_pi4)

y  = ROTY(pi/2)

