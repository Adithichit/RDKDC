function ROTX(scalar_roll) %input is scalar roll value in radians
R = [1 0 0;
    0, cos(scalar_roll), -sin(scalar_roll);
    0, sin(scalar_roll), cos(scalar_roll)];

PLOTR(R)
PLOTP3(R)
PLOTP4(R)
PLOTV3(R)
PLOTV4(R)
PLOTF(R)